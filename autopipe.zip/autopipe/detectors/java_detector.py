import xml.etree.ElementTree as ET
import re
from pathlib import Path
from typing import Optional
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class JavaDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        pom_path = project_root / "pom.xml"
        gradle_path = project_root / "build.gradle"
        gradle_kts_path = project_root / "build.gradle.kts"
        ant_path = project_root / "build.xml"

        if pom_path.exists():
            return self._analyze_maven(pom_path)
        elif gradle_path.exists() or gradle_kts_path.exists():
            return self._analyze_gradle(gradle_path if gradle_path.exists() else gradle_kts_path)
        elif ant_path.exists():
            return self._analyze_ant(ant_path)
        
        return None

    def _analyze_maven(self, pom_path: Path) -> DetectedStack:
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            # Handle namespaces if present (maven usually has them)
            ns = dict(mvn='http://maven.apache.org/POM/4.0.0')
            # Helper to find with namespace
            def find(path):
                # Try with namespace first, then without
                res = root.find(path, ns)
                if res is None:
                    # simplistic fallback for no-namespace xml
                    res = root.find(path.replace('mvn:', ''))
                return res

            # Detect Version
            java_version = "17" # Default
            props = find('mvn:properties')
            if props is not None:
                jv = props.find('mvn:java.version', ns)
                if jv is None: jv = props.find('java.version') # Try without ns
                
                if jv is not None and jv.text:
                    java_version = jv.text
                else:
                    # Check compiler source
                    source = props.find('mvn:maven.compiler.source', ns)
                    if source is None: source = props.find('maven.compiler.source')
                    if source is not None and source.text:
                        java_version = source.text

            # Detect Spring Boot
            framework = Framework.NONE
            parent = find('mvn:parent')
            if parent is not None:
                art_id = parent.find('mvn:artifactId', ns)
                if art_id is None: art_id = parent.find('artifactId')
                
                if art_id is not None and 'spring-boot' in (art_id.text or ""):
                    framework = Framework.SPRING_BOOT
            
            # Also check dependencies if parent not found
            if framework == Framework.NONE:
                deps = find('mvn:dependencies')
                if deps is not None:
                    for dep in deps.findall('mvn:dependency', ns):
                        art_id = dep.find('mvn:artifactId', ns)
                        if art_id is not None and 'spring-boot' in (art_id.text or ""):
                            framework = Framework.SPRING_BOOT
                            break

            return DetectedStack(
                language=Language.JAVA,
                framework=framework,
                build_tool=BuildTool.MAVEN,
                language_version=java_version,
                java_version=java_version
            )

        except Exception as e:
            # Fallback if parsing fails
            return DetectedStack(language=Language.JAVA, build_tool=BuildTool.MAVEN)

    def _analyze_gradle(self, gradle_path: Path) -> DetectedStack:
        content = gradle_path.read_text(encoding='utf-8')
        
        # Detect Version
        java_version = "17"
        # sourceCompatibility = '17' or JavaVersion.VERSION_17
        match = re.search(r"sourceCompatibility\s*=\s*['\"]?(\d+(?:\.\d+)?)['\"]?", content)
        if match:
            java_version = match.group(1)
        
        # Detect Framework
        framework = Framework.NONE
        if 'org.springframework.boot' in content or 'spring-boot' in content:
            framework = Framework.SPRING_BOOT

        return DetectedStack(
            language=Language.JAVA,
            framework=framework,
            build_tool=BuildTool.GRADLE,
            language_version=java_version,
            java_version=java_version
        )

    def _analyze_ant(self, ant_path: Path) -> DetectedStack:
        """Analyze Apache Ant build.xml for Java version and dependencies."""
        try:
            tree = ET.parse(ant_path)
            root = tree.getroot()
            
            # Default Java version
            java_version = "11"
            
            # Try to find javac task with target/source attributes
            for javac in root.iter('javac'):
                target = javac.get('target')
                source = javac.get('source')
                if target:
                    java_version = target
                    break
                if source:
                    java_version = source
                    break
            
            # Try to find property definitions
            for prop in root.iter('property'):
                name = prop.get('name', '')
                if 'java.target' in name or 'javac.target' in name or 'ant.build.javac.target' in name:
                    value = prop.get('value')
                    if value:
                        java_version = value
                        break
            
            # Detect framework (basic)
            framework = Framework.NONE
            content = ant_path.read_text(encoding='utf-8')
            if 'spring' in content.lower():
                framework = Framework.SPRING_BOOT
            
            return DetectedStack(
                language=Language.JAVA,
                framework=framework,
                build_tool=BuildTool.ANT,
                language_version=java_version,
                java_version=java_version
            )
        except Exception as e:
            # Fallback if parsing fails
            return DetectedStack(
                language=Language.JAVA, 
                build_tool=BuildTool.ANT,
                language_version="11",
                java_version="11"
            )

