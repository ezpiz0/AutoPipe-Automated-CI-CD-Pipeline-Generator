import json
from pathlib import Path
from typing import Optional
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class PhpDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        composer_json = project_root / "composer.json"
        
        if composer_json.exists():
            return self._analyze_composer(composer_json)
        return None

    def _analyze_composer(self, path: Path) -> DetectedStack:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            require = data.get("require", {})
            
            framework = Framework.NONE
            if "laravel/framework" in require:
                framework = Framework.LARAVEL
            elif "symfony/framework-bundle" in require or "symfony/symfony" in require:
                framework = Framework.SYMFONY
            
            version = "8.2"
            if "php" in require:
                # "^8.1" -> "8.1"
                v = require["php"]
                import re
                match = re.search(r'(\d+\.\d+)', v)
                if match:
                    version = match.group(1)

            return DetectedStack(
                language=Language.PHP,
                framework=framework,
                build_tool=BuildTool.COMPOSER,
                language_version=version,
                php_version=version
            )
        except Exception:
            return DetectedStack(language=Language.PHP, build_tool=BuildTool.COMPOSER)
