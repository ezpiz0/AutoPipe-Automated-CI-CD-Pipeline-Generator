import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class DotNetDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        # Look for any .csproj file
        csproj_files = list(project_root.glob("*.csproj"))
        if csproj_files:
            # Analyze the first one found, or maybe the one in root?
            # If multiple, usually a solution file .sln exists, but .csproj is the project.
            return self._analyze_csproj(csproj_files[0])
        return None

    def _analyze_csproj(self, path: Path) -> DetectedStack:
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            
            # <TargetFramework>net8.0</TargetFramework>
            target_framework = root.find(".//TargetFramework")
            version = "8.0" # Default
            if target_framework is not None and target_framework.text:
                tf = target_framework.text
                if tf.startswith("net"):
                    version = tf.replace("net", "")
            
            return DetectedStack(
                language=Language.DOTNET,
                framework=Framework.NONE, # ASP.NET Core is usually implied by SDK but let's keep it simple
                build_tool=BuildTool.DOTNET_CLI,
                language_version=version,
                dotnet_framework_version=version
            )
        except Exception:
            return DetectedStack(language=Language.DOTNET, build_tool=BuildTool.DOTNET_CLI)
