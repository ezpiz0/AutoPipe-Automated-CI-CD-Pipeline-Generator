import re
import sys
from pathlib import Path
from typing import Optional, Dict, Any

# Compatible TOML import
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        # Fallback for when tomli is not installed, though it should be
        tomllib = None

from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class PythonDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        pyproject_path = project_root / "pyproject.toml"
        requirements_path = project_root / "requirements.txt"

        if pyproject_path.exists() and tomllib:
            return self._analyze_pyproject(pyproject_path)
        elif requirements_path.exists():
            return self._analyze_requirements(requirements_path)
        
        # Check for setup.py as fallback
        if (project_root / "setup.py").exists():
             return DetectedStack(language=Language.PYTHON, build_tool=BuildTool.PIP)

        return None

    def _analyze_pyproject(self, path: Path) -> DetectedStack:
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
            
            tool_poetry = data.get("tool", {}).get("poetry", {})
            dependencies = tool_poetry.get("dependencies", {})
            
            # If not poetry, check project.dependencies (PEP 621)
            if not dependencies:
                dependencies = data.get("project", {}).get("dependencies", [])
                # Convert list to dict for easier checking if it's a list
                if isinstance(dependencies, list):
                    # Simplistic parsing "package>=1.0"
                    dep_dict = {}
                    for dep in dependencies:
                        name = re.split(r'[<>=!~]', dep)[0]
                        dep_dict[name] = dep
                    dependencies = dep_dict

            framework = Framework.NONE
            if "django" in dependencies or "Django" in dependencies:
                framework = Framework.DJANGO
            elif "fastapi" in dependencies or "FastAPI" in dependencies:
                framework = Framework.FASTAPI

            # Detect Python version
            # Poetry: python = "^3.9"
            python_version = "3.9"
            if "python" in dependencies:
                python_version = str(dependencies["python"]).replace("^", "").replace("~", "")

            return DetectedStack(
                language=Language.PYTHON,
                framework=framework,
                build_tool=BuildTool.POETRY if tool_poetry else BuildTool.PIP,
                language_version=python_version,
                python_version=python_version
            )
        except Exception:
            return DetectedStack(language=Language.PYTHON, build_tool=BuildTool.PIP)

    def _analyze_requirements(self, path: Path) -> DetectedStack:
        content = path.read_text(encoding='utf-8')
        
        framework = Framework.NONE
        if re.search(r'^django[=><]?', content, re.IGNORECASE | re.MULTILINE):
            framework = Framework.DJANGO
        elif re.search(r'^fastapi[=><]?', content, re.IGNORECASE | re.MULTILINE):
            framework = Framework.FASTAPI

        return DetectedStack(
            language=Language.PYTHON,
            framework=framework,
            build_tool=BuildTool.PIP,
            language_version="3.9" # Hard to detect from requirements.txt without runtime.txt
        )
