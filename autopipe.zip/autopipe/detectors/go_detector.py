import re
from pathlib import Path
from typing import Optional
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class GoDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        go_mod = project_root / "go.mod"
        
        if go_mod.exists():
            return self._analyze_go_mod(go_mod)
        return None

    def _analyze_go_mod(self, path: Path) -> DetectedStack:
        content = path.read_text(encoding='utf-8')
        
        # Detect version "go 1.21"
        version = "1.21"
        match = re.search(r'^go\s+(\d+(?:\.\d+)?)', content, re.MULTILINE)
        if match:
            version = match.group(1)
            
        # Detect Frameworks (Gin, Echo, Fiber, etc. - though prompt didn't specify these strictly, good to have)
        # Prompt mentioned "Go Modules" as the ecosystem.
        framework = Framework.NONE
        # Example: require github.com/gin-gonic/gin v1.9.0
        
        return DetectedStack(
            language=Language.GO,
            framework=framework,
            build_tool=BuildTool.GO_MOD,
            language_version=version,
            go_version=version
        )
