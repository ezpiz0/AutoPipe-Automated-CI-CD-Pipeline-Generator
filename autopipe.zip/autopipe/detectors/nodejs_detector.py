import json
from pathlib import Path
from typing import Optional
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack, Language, Framework, BuildTool

class NodeJSDetector(Detector):
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        package_json = project_root / "package.json"
        
        if package_json.exists():
            return self._analyze_package_json(package_json, project_root)
        return None

    def _analyze_package_json(self, path: Path, root: Path) -> DetectedStack:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            dependencies = data.get("dependencies", {})
            dev_dependencies = data.get("devDependencies", {})
            all_deps = {**dependencies, **dev_dependencies}
            
            framework = Framework.NONE
            if "react" in all_deps:
                framework = Framework.REACT
            elif "@nestjs/core" in all_deps:
                framework = Framework.NESTJS
            
            # Detect Build Tool
            build_tool = BuildTool.NPM
            if (root / "yarn.lock").exists():
                build_tool = BuildTool.YARN
            
            # Detect Node Version (engines)
            node_version = "18" # LTS default
            engines = data.get("engines", {})
            if "node" in engines:
                # Clean up version string ">=14.0.0" -> "14"
                v = engines["node"]
                import re
                match = re.search(r'(\d+)', v)
                if match:
                    node_version = match.group(1)

            return DetectedStack(
                language=Language.NODEJS,
                framework=framework,
                build_tool=build_tool,
                language_version=node_version,
                node_version=node_version
            )
        except Exception:
            return DetectedStack(language=Language.NODEJS, build_tool=BuildTool.NPM)
