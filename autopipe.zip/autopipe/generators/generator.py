import logging
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from autopipe.core.models import ProjectContext

logger = logging.getLogger("autopipe")

class Generator:
    def __init__(self, template_dir: Path):
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(),
            trim_blocks=True,
            lstrip_blocks=True
        )

    def generate(self, context: ProjectContext, output_dir: Path):
        logger.info(f"Generating configuration for {context.metadata.name}...")
        
        self._render_template("dockerfile.j2", context, output_dir / "Dockerfile")
        self._render_template("gitlab-ci.j2", context, output_dir / ".gitlab-ci.yml")
        
        logger.info("Generation complete.")

    def _render_template(self, template_name: str, context: ProjectContext, output_path: Path):
        template = self.env.get_template(template_name)
        # Pass context as dict or object. accessing via dot notation in jinja requires object or dict.
        # Pydantic models can be accessed via dot notation if passed directly? 
        # Jinja handles objects fine.
        content = template.render(
            stack=context.stack,
            metadata=context.metadata,
            context=context
        )
        
        output_path.write_text(content, encoding="utf-8")
        logger.info(f"Generated: {output_path}")
