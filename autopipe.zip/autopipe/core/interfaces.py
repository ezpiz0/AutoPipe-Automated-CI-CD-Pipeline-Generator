from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional
from autopipe.core.models import DetectedStack

class Detector(ABC):
    @abstractmethod
    def detect(self, project_root: Path) -> Optional[DetectedStack]:
        """
        Analyze the given directory and return a DetectedStack if this detector's
        language/framework is found.
        """
        pass
