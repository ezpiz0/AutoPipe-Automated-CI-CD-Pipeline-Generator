from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class Language(str, Enum):
    JAVA = "java"
    PYTHON = "python"
    NODEJS = "nodejs"
    GO = "go"
    DOTNET = "dotnet"
    PHP = "php"
    UNKNOWN = "unknown"

class Framework(str, Enum):
    SPRING_BOOT = "spring_boot"
    DJANGO = "django"
    FASTAPI = "fastapi"
    REACT = "react"
    NESTJS = "nestjs"
    LARAVEL = "laravel"
    SYMFONY = "symfony"
    NONE = "none"

class BuildTool(str, Enum):
    MAVEN = "maven"
    GRADLE = "gradle"
    ANT = "ant"
    NPM = "npm"
    YARN = "yarn"
    POETRY = "poetry"
    PIP = "pip"
    GO_MOD = "go_mod"
    DOTNET_CLI = "dotnet_cli"
    COMPOSER = "composer"
    NONE = "none"

class Dependency(BaseModel):
    name: str
    version: str
    is_dev: bool = False

class ProjectMetadata(BaseModel):
    name: str
    version: str = "0.1.0"
    description: Optional[str] = None
    
class DetectedStack(BaseModel):
    language: Language
    framework: Framework = Framework.NONE
    build_tool: BuildTool = BuildTool.NONE
    language_version: str = "latest"
    dependencies: List[Dependency] = Field(default_factory=list)
    
    # Specific configs
    java_version: Optional[str] = None
    dotnet_framework_version: Optional[str] = None # e.g. net8.0
    node_version: Optional[str] = None
    python_version: Optional[str] = None
    go_version: Optional[str] = None
    php_version: Optional[str] = None

class ProjectContext(BaseModel):
    metadata: ProjectMetadata
    stack: DetectedStack
    root_path: str
    source_path: str = "." # Path to source code relative to root
    docker_context: str = "."
    
    # For monorepos or complex structures, we might need a list of sub-projects
    # But for now, we assume we resolve to a single "main" project to build per the "Conflict Resolution" requirement
    # or we model it as one primary artifact.
    
    extra_vars: Dict[str, Any] = Field(default_factory=dict)
