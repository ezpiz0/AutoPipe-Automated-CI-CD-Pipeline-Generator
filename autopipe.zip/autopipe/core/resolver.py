import logging
from typing import List
from autopipe.core.models import ProjectContext, DetectedStack, ProjectMetadata, Language, Framework

logger = logging.getLogger("autopipe")

class Resolver:
    # Priority list: Lower index = Higher priority
    LANGUAGE_PRIORITY = [
        Language.JAVA,
        Language.DOTNET,
        Language.GO,
        Language.PYTHON,
        Language.PHP,
        Language.NODEJS, # Need to refine based on framework
    ]

    def resolve(self, detected_stacks: List[DetectedStack], root_path: str) -> ProjectContext:
        if not detected_stacks:
            raise ValueError("No technology stack detected. Cannot generate pipeline.")

        # Sort stacks by priority
        sorted_stacks = sorted(detected_stacks, key=self._get_priority)
        
        # Pick the winner
        winner = sorted_stacks[0]
        logger.info(f"Resolved primary stack: {winner.language} ({winner.framework})")

        # Create Context
        # In a real scenario, we might extract name/version from the stack's metadata if available
        metadata = ProjectMetadata(
            name=f"auto-generated-{winner.language.value}",
            version="0.1.0"
        )

        return ProjectContext(
            metadata=metadata,
            stack=winner,
            root_path=root_path
        )

    def _get_priority(self, stack: DetectedStack) -> int:
        base_priority = 999
        try:
            base_priority = self.LANGUAGE_PRIORITY.index(stack.language)
        except ValueError:
            pass
            
        # Adjust for Frontend vs Backend Node
        if stack.language == Language.NODEJS:
            if stack.framework in [Framework.NESTJS]:
                # Treat as backend, keep priority (maybe slightly lower than compiled langs)
                pass 
            elif stack.framework in [Framework.REACT, Framework.NONE]:
                # Treat as frontend, lower priority
                base_priority += 100
        
        return base_priority
