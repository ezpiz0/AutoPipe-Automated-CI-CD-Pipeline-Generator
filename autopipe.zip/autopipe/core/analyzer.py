import logging
from pathlib import Path
from typing import List, Type
from autopipe.core.interfaces import Detector
from autopipe.core.models import DetectedStack

# We will import specific detectors here later or inject them
# from autopipe.detectors.java_detector import JavaDetector
# ...

logger = logging.getLogger("autopipe")

class Analyzer:
    def __init__(self):
        self.detectors: List[Detector] = []

    def register_detector(self, detector: Detector):
        self.detectors.append(detector)

    def analyze(self, project_root: Path) -> List[DetectedStack]:
        """
        Runs all registered detectors on the project root.
        Returns a list of all detected stacks (could be multiple in a mixed repo).
        """
        logger.info(f"Analyzing project structure at {project_root}...")
        results = []
        for detector in self.detectors:
            try:
                result = detector.detect(project_root)
                if result:
                    logger.info(f"Detector {detector.__class__.__name__} found match: {result.language}")
                    results.append(result)
            except Exception as e:
                logger.error(f"Detector {detector.__class__.__name__} failed: {e}")
        
        return results
