import typer
import sys
from typing import Optional
from pathlib import Path
from rich.console import Console
from rich.logging import RichHandler
import logging

app = typer.Typer(
    name="autopipe",
    help="AutoPipe: Deterministic CI/CD Pipeline Generator",
    add_completion=False,
)
console = Console()

def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True)]
    )

@app.command()
def generate(
    repo_url: str = typer.Argument(..., help="URL or path to the Git repository"),
    output_dir: Path = typer.Option(Path("."), "--output", "-o", help="Directory to output generated files"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose logging"),
):
    """
    Analyze a repository and generate CI/CD configuration.
    """
    setup_logging(verbose)
    logger = logging.getLogger("autopipe")
    
    logger.info(f"Starting AutoPipe analysis for: {repo_url}")
    
    from autopipe.core.fetcher import Fetcher
    from autopipe.core.analyzer import Analyzer
    from autopipe.core.resolver import Resolver
    from autopipe.generators.generator import Generator
    from autopipe.validators.validator import Validator
    from autopipe.core.reporter import Reporter
    
    # Register Detectors
    from autopipe.detectors.java_detector import JavaDetector
    from autopipe.detectors.python_detector import PythonDetector
    from autopipe.detectors.nodejs_detector import NodeJSDetector
    from autopipe.detectors.go_detector import GoDetector
    from autopipe.detectors.dotnet_detector import DotNetDetector
    from autopipe.detectors.php_detector import PhpDetector

    fetcher = Fetcher(repo_url)
    analyzer = Analyzer()
    analyzer.register_detector(JavaDetector())
    analyzer.register_detector(PythonDetector())
    analyzer.register_detector(NodeJSDetector())
    analyzer.register_detector(GoDetector())
    analyzer.register_detector(DotNetDetector())
    analyzer.register_detector(PhpDetector())
    
    resolver = Resolver()
    # Assume templates are in the 'templates' dir relative to where we run, or package them.
    # For this standalone script, we assume they are in d:/Downloads/T1/templates
    # In a real package, we'd use pkg_resources or similar.
    template_dir = Path(__file__).resolve().parent.parent / "templates"
    generator = Generator(template_dir)
    validator = Validator()
    reporter = Reporter()

    try:
        # 1. Fetch
        project_root = fetcher.fetch()
        
        # 2. Analyze
        detected_stacks = analyzer.analyze(project_root)
        
        # 3. Resolve
        context = resolver.resolve(detected_stacks, str(project_root))
        
        # 4. Generate
        output_dir.mkdir(parents=True, exist_ok=True)
        generator.generate(context, output_dir)
        
        # 5. Validate
        success = validator.validate(output_dir)
        
        # 6. Report
        reporter.report(context, output_dir, success)
        
        if not success:
            logger.error("Validation failed. See report for details.")
            sys.exit(1)
            
    except Exception as e:
        logger.exception("An error occurred during execution")
        sys.exit(1)
    finally:
        fetcher.cleanup()

if __name__ == "__main__":
    app()
